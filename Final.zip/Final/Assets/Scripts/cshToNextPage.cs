using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class cshToNextPage : MonoBehaviour
{
    // Start is called before the first frame update
    public void ChangeMainScene ()
    {
        SceneManager.LoadScene("main");
    }

    // Update is called once per frame
    public void ChangeInputScene()
    {
        SceneManager.LoadScene("studentInput");
    }

    public void ChangeGameScene() {
	SceneManager.LoadScene("Play");
    } 

    
}
