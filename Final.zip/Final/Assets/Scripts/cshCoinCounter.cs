using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class cshCoinCounter : MonoBehaviour
{
    Text txt;
    
   
    void Start()
    {
	txt = gameObject.GetComponent<Text>(); 
         txt.text= "남은 문제 갯수 : " + GameObject.FindGameObjectsWithTag("Coin").Length.ToString();
    }
}
