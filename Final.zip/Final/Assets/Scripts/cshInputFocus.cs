using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 
public class cshInputFocus : MonoBehaviour
{

    public InputField input;
    // Start is called before the first frame update
    void Start()
    {
		input.ActivateInputField(); 
    }

    }
